﻿using System;
using System.Collections.Generic;
using Polymorphism_Dan_Collection.ClassAnak;
using Polymorphism_Dan_Collection.ClassInduk;

namespace Polymorphism_Dan_Collection.ClassInduk
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Polymorphism Dan Collection";

            KaryawanTetap karyawanTetap = new KaryawanTetap();
            karyawanTetap.Nik = "2123.222.2323";
            karyawanTetap.Nama = "Upin dan Ipin";
            karyawanTetap.GajiBulanan = 2350000;

            KaryawanHarian karyawanHarian = new KaryawanHarian();
            karyawanHarian.Nik = "2222.121.7873";
            karyawanHarian.Nama = "Mei-Mei dan Susanti";
            karyawanHarian.JumlahJamKerja = 3;
            karyawanHarian.UpahPerJam = 6480000;

            Sales sales = new Sales();
            sales.Nik = "9898.765.000";
            sales.Nama = "Kucing dan Meong";
            sales.JumlahPenjualan = 19;
            sales.Komisi = 9800000;

            List<Karyawan> listKaryawan = new List<Karyawan>();

            listKaryawan.Add(karyawanTetap);
            listKaryawan.Add(karyawanHarian);
            listKaryawan.Add(sales);

            int noUrut = 1;

            foreach (Karyawan karyawan in listKaryawan)
            {
                Console.WriteLine("{0}. Nik : {1}, Nama : {2}, Gaji : Rp.{3 : 0}", noUrut, karyawan.Nik, karyawan.Nama, karyawan.Gaji());

                noUrut++;

            }

            Console.ReadKey();

        }
    }
}

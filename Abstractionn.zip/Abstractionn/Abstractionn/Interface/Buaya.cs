﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Abstractionn.Abstracclass
{
    public class Keyboard : IHewan
    {
        public void Dimakan()
        {
            Console.WriteLine("Buaya paling enak dimakan dengan cara di oseng");
            Console.WriteLine("Buaya yang suka main di darat adalah buaya darat");
        }
    }
}

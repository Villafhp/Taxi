﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Abstractionn.Abstracclass
{
    public interface IHewan
    {
        void Dimakan();
    }
}
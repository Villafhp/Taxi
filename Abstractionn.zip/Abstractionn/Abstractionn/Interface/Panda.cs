﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstractionn.Abstracclass
{
    public class Mouse : IHewan
    {
        public void Dimakan()
        {
            Console.WriteLine("Firasat saya daging panda itu lembut");
            Console.WriteLine("Panda merupakan hewan paling lucu sejagat raya");
        }
    }
}

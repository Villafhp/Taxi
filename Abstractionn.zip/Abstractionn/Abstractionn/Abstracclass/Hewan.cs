﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Abstractionn.Abstracclass
{
    public abstract class Hewan
    {
        public abstract void Dimakan();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Abstractionn.Abstracclass
{
    public class Panda : Hewan
    {
        public override void Dimakan()
        {
            Console.WriteLine("Firasat saya daging panda itu lembut");
            Console.WriteLine("Panda merupakan hewan paling lucu sejagat raya");
        }
    }
}


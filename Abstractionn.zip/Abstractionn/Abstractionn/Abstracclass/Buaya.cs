﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Abstractionn.Abstracclass
{
    public class Buaya : Hewan
    {
        public override void Dimakan()
        {
            Console.WriteLine("Buaya paling enak dimakan dengan cara di oseng");
            Console.WriteLine("Buaya yang suka main di darat adalah buaya darat");
        }
    }
}

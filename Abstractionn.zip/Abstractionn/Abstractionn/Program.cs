﻿using System;
using Abstractionn.Abstracclass;

namespace Abstractionn
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Hewan hewan;

            hewan = new Buaya();
            hewan.Dimakan();

            Console.WriteLine();
            hewan = new Panda();
            hewan.Dimakan();*/

            Hewan hewan;

            hewan = new Buaya();
            hewan.Dimakan();

            Console.WriteLine();
            hewan = new Panda();
            hewan.Dimakan();

            Console.ReadKey();
        }
    }
}

﻿using System;

namespace latihaninheritance
{
    public class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Villa", 19);
            person.GetNameAndAge();

            Teacher teacher = new Teacher("Soleh", 44, "3434521", "Agama");
            teacher.GetNameAndAge();

            Student student = new Student("Leon", 20, "2907", "leon.el@students.amikom.ac.id");
            student.GetNameAndAge();

          
            Console.ReadKey();
        }
    }
}

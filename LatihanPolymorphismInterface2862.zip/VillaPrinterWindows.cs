﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LatihanPolymorphismInterface2862
{
    public interface VillaPrinterWindows
    {
        void Show()
        {
        }
        void Print()
        {
        }
    }
}

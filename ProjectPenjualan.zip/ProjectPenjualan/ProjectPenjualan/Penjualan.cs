﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectPenjualan
{
    public class Penjualan
    {
        // PERINTAH: lengkapi property class penjualan, sesuai petunjuk soal
        public int Nota { get; set; }
        public string Tanggal { get; set; }
        public string Nama { get; set; }
        public char Jenis { get; set; }
        public double TotalNota { get; set; }
    }
}
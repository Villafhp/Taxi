﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;

namespace ProjectPenjualan
{
    class Program
    {
        // deklarasi objek collection untuk menampung objek penjualan
        static List<Penjualan> daftarPenjualan = new List<Penjualan>();

        static void Main(string[] args)
        {
            Console.Title = "Responsi UAS Matakuliah Pemrograman";

            while (true)
            {

                TampilMenu();

                Console.Write("\nNomor Menu [1..4]: ");
                int nomorMenu = Convert.ToInt32(Console.ReadLine());


                switch (nomorMenu)
                {
                    case 1:
                        TambahPenjualan();
                        break;

                    case 2:
                        HapusPenjualan();
                        break;

                    case 3:
                        TampilPenjualan();
                        break;

                    case 4: // keluar dari program
                        return;

                    default:
                        break;
                }
            }
        }

        static void TampilMenu()
        {
            Console.Clear();

            Console.WriteLine("Pilih Menu Aplikasi\n\n");
            Console.WriteLine("1. Tambah Penjualan");
            Console.WriteLine("2. Hapus Penjualan");
            Console.WriteLine("3. Tampilkan Penjualan");

            // PERINTAH: lengkapi kode untuk menampilkan menu
        }

        static void TambahPenjualan()
        {
            Console.Clear();
            int nota;
            double total;
            string tanggal, customer;
            char jenis;

            Console.WriteLine("Nota         : ");
            nota = int.Parse(Console.ReadLine());
            Console.WriteLine("Tanggal      : ");
            tanggal = Console.ReadLine();
            Console.WriteLine("Customer     : ");
            customer = Console.ReadLine();
            Console.WriteLine("Jenis [T/K]  : ");
            jenis = char.Parse(Console.ReadLine());
            Console.WriteLine("Total Nota   : ");
            total = double.Parse(Console.ReadLine());

            daftarPenjualan.Add(new Penjualan() { Nota = nota, Tanggal = tanggal, Jenis = jenis, TotalNota = total });

            // PERINTAH: lengkapi kode untuk menambahkan penjualan ke dalam collection

            Console.WriteLine("\nTekan ENTER untuk kembali ke menu");
            Console.ReadKey();

        }

        static void HapusPenjualan()
        {
            Console.Clear();

            // PERINTAH: lengkapi kode untuk menghapus penjualan dari dalam collection

            int v = 0;
            int hapus;

            Console.WriteLine("Hapus Data Penjualan\n\n");
            Console.Write("Nota     : ");
            hapus = Convert.ToInt32(Console.ReadLine());

            foreach (Penjualan penjual in daftarPenjualan)
            {
                if (hapus == penjual.Nota)
                {
                    daftarPenjualan.RemoveAt(v);
                    break;
                }
                v++;
            }
            Console.WriteLine("\nTekan ENTER untuk kembali ke menu");
            Console.ReadKey();

        }

        static void TampilPenjualan()
        {
            Console.Clear();

            // PERINTAH: lengkapi kode untuk menampilkan daftar penjualan yang ada di dalam collection

            int jumlah = 1;
            Console.WriteLine("Daftar Penjualan\n\n");

            foreach (Penjualan jual in daftarPenjualan)
            {
                if (jual.Jenis == 'T' || jual.Jenis == 't')
                {
                    Console.WriteLine("{0}, {1}, {2}, {3}, TUNAI, {4}", jumlah, jual.Nota, jual.Tanggal, jual.Nama, jual.TotalNota);
                }
                else if (jual.Jenis == 'K' || jual.Jenis == 'k')
                {
                    Console.WriteLine("{0}, {1}, {2}, {3}, KREDIT, {4}", jumlah, jual.Nota, jual.Tanggal, jual.Nama, jual.TotalNota);
                }
                jumlah++;
            }
            Console.WriteLine("\nTekan enter untuk kembali ke menu");
            Console.ReadKey();

        }
    }
}
